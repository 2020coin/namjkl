import React from 'react';

const Button = () => (
  <div className="div1">
    <button type="button" className="btn">
      버튼
    </button>
    <style jsx>
      {`

        @import url(https://fonts.googleapis.com/css?family=Nanum+Gothic);

        .btn {
          position: absolute;
          left: 50%;
          top: 50%;
          transform: translate(-50%, -50%);
          width: 100px;
          height: 40px;
          border-radius: 10px;
          box-shading: 0px 0px 3px 0px;
          background-image: linear-gradient(135deg, #00CED1, #00008B 30%, #00008B 50%, #9400D3);
          color: white;
          font-weight: bold;
        }

        .btn:hover {
          cursor: pointer;
          width: 130px;
          height: 50px;
          transition: all ease 0.5s 0s;
          font-size: 20px;  
        }
      `}
    </style>
  </div>
);

export default Button;